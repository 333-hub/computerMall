package com.xsx.computermall.util;

import java.util.logging.Logger;

/**
 * 日志类文件
 * @author xiong
 *2018年12月2日上午11:56:21
 */
public class LogUtil {
	public static Logger log = Logger.getLogger(String.valueOf(LogUtil.class));
}
